(function() {
  'use strict';

  angular.module('org.bonitasoft.common.i18n', [
    'ngCookies',
    'gettext',
    'org.bonitasoft.common.resources'
  ]);

})();
