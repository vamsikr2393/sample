(function(module) {
try {
  module = angular.module('org.bonitasoft.portalTemplates');
} catch (e) {
  module = angular.module('org.bonitasoft.portalTemplates', []);
}
module.run(['$templateCache', function($templateCache) {
  $templateCache.put('portalTemplates/user/tasks/list/tasks-list.html',
    '<!-- Reset style for the page. Dirty but avoid having to break all other pages -->\n' +
    '<style>\n' +
    '    html, body, body #content {\n' +
    '        height: 100%;\n' +
    '        margin: 0;\n' +
    '    }\n' +
    '</style>\n' +
    '<toast></toast>\n' +
    '<div class="TaskListPage" ng-cloak task-app form-spy spy-submit="app.onFormSubmited(message)"\n' +
    '     ng-class="{\n' +
    '      \'TaskListPage--small\':app.smallScreen,\n' +
    '      \'TaskListPage--withMenu\':!app.smallScreen && app.showMenu}">\n' +
    '    <div class="OffcanvasMenu navbar">\n' +
    '        <button ng-if="!app.smallScreen && app.showMenu" title="{{ \'Hide Menu\' | translate }}"\n' +
    '                class="FilterToggle" ng-click="app.toggleFilters()">\n' +
    '            <span class="glyphicon glyphicon-menu-left"></span>\n' +
    '            <span class="sr-only" translate>Hide menu</span>\n' +
    '        </button>\n' +
    '        <button ng-if="!app.smallScreen && !app.showMenu" title="{{ \'Show Menu\' | translate }}"\n' +
    '                class="FilterToggle FilterToggle-expend" ng-click="app.toggleFilters()">\n' +
    '            <span class="glyphicon glyphicon-menu-right"></span>\n' +
    '            <span class="sr-only" translate>Show menu</span>\n' +
    '        </button>\n' +
    '        <task-filters filter="app.request.taskFilter"\n' +
    '                      filters="app.TASK_FILTERS"\n' +
    '                      count="app.count"\n' +
    '                      filter-change="app.changeFilter(filter)">\n' +
    '        </task-filters>\n' +
    '    </div>\n' +
    '    <div class="TaskList" ng-if="!error">\n' +
    '        <div class="TaskList-filters panel panel-default">\n' +
    '            <div class="panel-heading title ng-binding" translate>Filters</div>\n' +
    '            <div class="panel-body">\n' +
    '               <div class="row">\n' +
    '                <div class="col-md-7 button-filter ng-binding" ng-hide="app.request.taskFilter === app.TASK_FILTERS.DONE">\n' +
    '                    {{ \'Process\' | translate }}\n' +
    '                    <div class="btn-group dropdown Filter-process" dropdown="">\n' +
    '                        <button dropdown-toggle type="button"\n' +
    '                                class="btn btn-primary"\n' +
    '                                title="{{\'Process:\' | translate }} {{ app.request.process.displayName + (app.request.process.version ? \' \' + app.request.process.version : \'\') }}"\n' +
    '                                ng-disabled="app.request.taskFilter === app.TASK_FILTERS.DONE || !app.processes || app.processes.length === 0">\n' +
    '                            <div class="ProcessList-label">\n' +
    '                                {{app.request.process.displayName + (app.request.process.version?"\n' +
    '                                "+app.request.process.version:"")}}\n' +
    '                                <span class="caret"></span>\n' +
    '                            </div>\n' +
    '                        </button>\n' +
    '                        <ul class="dropdown-menu">\n' +
    '                            <li ng-repeat="p in app.processes">\n' +
    '                                <a ng-click="app.setProcess(p)"\n' +
    '                                   ng-class="{\'active\':p.id === app.request.process.id}"\n' +
    '                                   class="processOptionLink">\n' +
    '                                    {{p.displayName+"&nbsp;"+p.version}}\n' +
    '                                </a>\n' +
    '                            </li>\n' +
    '                        </ul>\n' +
    '                    </div>\n' +
    '                  </div>\n' +
    '                  <div class="col-md-5" ng-class="{\'col-md-offset-7\': app.request.taskFilter === app.TASK_FILTERS.DONE}">\n' +
    '                    <form class="form-inline btn-group pull-right">\n' +
    '                      {{ \'Case\' | translate }}\n' +
    '                      <div class="form-group Filter-process">\n' +
    '                        <input type="text" ng-model="app.request.caseId" class="form-control TaskFilter-caseIdInput" id="case" name="case" placeholder="{{\'Case ID\' | translate}}"\n' +
    '                             ng-model-options="{updateOn:\'blur\'}"\n' +
    '                             ng-change="app.searchTask()" tooltip-template="\'tooltip-case-filter.html\'" tooltip-placement="right" tooltip-popup-delay="500" tooltip-animation="false" tooltip-append-to-body="true">\n' +
    '                      </div>\n' +
    '                      <script type="text/ng-template" id="tooltip-case-filter.html">\n' +
    '                        <span translate>Type in a case id and <br/> press enter to search for <br/> human task of a specific case</span>\n' +
    '                      </script>\n' +
    '                    </form>\n' +
    '                </div>\n' +
    '              </div>\n' +
    '             <div class="row">\n' +
    '                <div class="col-md-12">\n' +
    '                    <form role="form" name="searchForm" class="SearchBox" novalidate="" ng-submit="app.searchTask()">\n' +
    '                        <div class="input-group TaskList--paddingTop">\n' +
    '                            <input class="form-control SearchBox-input" id="search"\n' +
    '                                   input-focus\n' +
    '                                   placeholder="{{ \'Search...\' | translate }}"\n' +
    '                                   ng-model="app.request.search"\n' +
    '                                   ng-model-options="{updateOn:\'keyup\', debounce:{\'default\':250, \'blur\':0} }"\n' +
    '                                   ng-change="app.searchTask()">\n' +
    '                            <span ng-click="app.searchTask()" class="input-group-addon pointer">\n' +
    '                                <span class="glyphicon glyphicon-search"></span>\n' +
    '                            </span>\n' +
    '                        </div>\n' +
    '                        <span class="help-block pull-right" translate>In task name column</span>\n' +
    '                    </form>\n' +
    '                </div>\n' +
    '              </div>\n' +
    '            </div>\n' +
    '        </div>\n' +
    '        <div class="TaskList-table panel panel-default">\n' +
    '            <div class="panel-heading title ng-binding">\n' +
    '                <span translate>Task list</span>\n' +
    '                <button class="TaskList-refresh" style="background: transparent; border: none" ng-click="app.updateAll()"\n' +
    '                        ng-class="{ \'u-spin TaskList-loadingIcon\': app.loadingTasks }" title="{{ \'Refresh data\' | translate }}">\n' +
    '                    <i class="glyphicon glyphicon-repeat"></i>\n' +
    '                </button>\n' +
    '                <span ng-show="app.loadingTasks" class="TaskList-loadingText">{{ \'Loading...\' | translate }}</span>\n' +
    '            </div>\n' +
    '            <div class="panel-body">\n' +
    '                <task-table tasks="app.tasks"\n' +
    '                           current-task="app.currentTask"\n' +
    '                           request="app.request"\n' +
    '                           user="app.user"\n' +
    '                           mode="app.getMode(app.showDetails, app.smallScreen)"\n' +
    '                           page-sizes="app.PAGE_SIZES"\n' +
    '                           refresh="app.updateAll()"\n' +
    '                           select-task="app.selectTask(task)"\n' +
    '                           do-task="app.showTaskDetailsPopup()"\n' +
    '                           counters="app.count"\n' +
    '                           filter="app.filter">\n' +
    '                </task-table>\n' +
    '            </div>\n' +
    '        </div>\n' +
    '    </div>\n' +
    '\n' +
    '    <div class="TaskDetailsPanel" id="details" ng-class="{\'TaskDetailsPanel--collapsed\':!app.showDetails}">\n' +
    '        <button ng-if="!app.showDetails" class="SizeBar-expand"\n' +
    '                ng-click="app.toggleDetails()"\n' +
    '                title="{{\'Show panel\' | translate}}">\n' +
    '            <span class="glyphicon glyphicon-menu-left"></span>\n' +
    '            <span class="sr-only" translate>Show panel</span>\n' +
    '        </button>\n' +
    '        <button class="SizeBar-reduce"\n' +
    '                ng-if="app.showDetails"\n' +
    '                ng-click="app.toggleDetails()"\n' +
    '                title="{{ \'Hide panel\' | translate}}">\n' +
    '            <span class="glyphicon glyphicon-menu-right"></span>\n' +
    '            <span class="sr-only" translate>Hide panel</span>\n' +
    '        </button>\n' +
    '\n' +
    '        <div class="TaskDetailsPanel-content" ng-if="app.smallScreen || app.showDetails">\n' +
    '\n' +
    '            <div ng-if="app.tasks.length === 0" class="TaskDetailsPanel-content--empty" translate>\n' +
    '                This is the task details panel. No information to display\n' +
    '            </div>\n' +
    '\n' +
    '            <task-details ng-if="app.tasks.length"\n' +
    '                    current-task="app.currentTask"\n' +
    '                    refresh="app.refresh()"\n' +
    '                    open-details-popup="app.showTaskDetailsPopup()">\n' +
    '            </task-details>\n' +
    '        </div>\n' +
    '    </div>\n' +
    '</div>\n' +
    '');
}]);
})();

(function(module) {
try {
  module = angular.module('org.bonitasoft.portalTemplates');
} catch (e) {
  module = angular.module('org.bonitasoft.portalTemplates', []);
}
module.run(['$templateCache', function($templateCache) {
  $templateCache.put('portalTemplates/user/tasks/list/comments/comments.html',
    '<section class="Comments">\n' +
    '    <header class="Comments-header" translate>\n' +
    '        Case comments\n' +
    '    </header>\n' +
    '\n' +
    '    <div class="Comments-content" scroll-bottom="vm.comments">\n' +
    '        <div class="Comment" ng-repeat="comment in vm.comments">\n' +
    '            <img class="Comment-icon" ng-src="../theme/{{comment.userId.icon}}" alt="Author" onerror="this.style.display=\'none\'"/>\n' +
    '            <div class="Comment-header">\n' +
    '                {{ comment.userId.firstname + \' \' + comment.userId.lastname }} <span class="text-muted">{{ comment.postDate | moment:\'lll\' }}</span>\n' +
    '            </div>\n' +
    '            <div class="Comment-content">{{ comment.content }}</div>\n' +
    '        </div>\n' +
    '        <div ng-if="vm.comments.length == 0" class="text-muted" translate>No comment on this case yet. To add one, use the input field at the bottom of this panel</div>\n' +
    '    </div>\n' +
    '\n' +
    '    <footer class="Comments-footer">\n' +
    '        <form name="CaseCommentsForm" class="CommentForm" ng-class="{ \'text-muted\': !vm.isCurrentCaseOpened() }" ng-submit="vm.addComment(vm.newComment)">\n' +
    '        <div class="form-group" ng-class="{\'has-error\': CaseCommentsForm.$error.maxlength }">\n' +
    '            <textarea id="comment" class="form-control"\n' +
    '                      placeholder="{{ \'New comment\' | translate }}"\n' +
    '                      ng-model="vm.newComment"\n' +
    '                      ng-maxlength="255"\n' +
    '                      ng-required="true"\n' +
    '                      ng-disabled="!vm.isCurrentCaseOpened()">\n' +
    '            </textarea>\n' +
    '            <span class="help-block CommentForm-help" translate>Maximum size 255 characters</span>\n' +
    '        </div>\n' +
    '        <button type="submit" class="btn btn-default" ng-disabled="CaseCommentsForm.$invalid" translate>Add</button>\n' +
    '        <span ng-if="!vm.isCurrentCaseOpened()" class="CommentForm-disabledMsg" translate>The case is archived. You cannot add comments anymore</span>\n' +
    '    </form>\n' +
    '    </footer>\n' +
    '\n' +
    '</section>\n' +
    '');
}]);
})();

(function(module) {
try {
  module = angular.module('org.bonitasoft.portalTemplates');
} catch (e) {
  module = angular.module('org.bonitasoft.portalTemplates', []);
}
module.run(['$templateCache', function($templateCache) {
  $templateCache.put('portalTemplates/user/tasks/list/details/task-details-modal.html',
    '<div class="modal-body">\n' +
    '    <button type="button" class="pull-right close Modal-dismiss" title="{{ \'Close\' | translate }}" aria-label="{{ \'Close\' | translate }}" ng-click="modal.cancel()" >\n' +
    '        <span>&times;</span>\n' +
    '    </button>\n' +
    '    <task-details current-task="modal.currentTask"\n' +
    '                  refresh-count="modal.updateCount()">\n' +
    '    </task-details>\n' +
    '</div>\n' +
    '<div class="modal-footer">\n' +
    '    <button type="button" class="btn btn-primary" title="{{ \'Close\' | translate }}" ng-click="modal.cancel()" translate>Close</button>\n' +
    '</div>\n' +
    '');
}]);
})();

(function(module) {
try {
  module = angular.module('org.bonitasoft.portalTemplates');
} catch (e) {
  module = angular.module('org.bonitasoft.portalTemplates', []);
}
module.run(['$templateCache', function($templateCache) {
  $templateCache.put('portalTemplates/user/tasks/list/details/task-details.html',
    '<div ng-if="showToolbar" class="pull-right TaskDetailsPanel-toolbar" role="group">\n' +
    '    <button ng-if="!isEditable() && isAssignable()" class="Toolbar-button"\n' +
    '            id="ButtonTakeDetails"\n' +
    '            ng-click="onTakeReleaseTask()"\n' +
    '            title="{{ \'Make this task personal: only I will be able to do it\' | translate }}">\n' +
    '        <i class="icon-assigned"></i>\n' +
    '        <span class="sr-only" translate>Take</span>\n' +
    '    </button>\n' +
    '    <button ng-if="isEditable() && isAssignable()" class="Toolbar-button"\n' +
    '            id="ButtonReleaseDetails"\n' +
    '            ng-click="onTakeReleaseTask()"\n' +
    '            title="{{ \'Make this task available to other team members again\' | translate }}">\n' +
    '        <i class="icon-unassigned"></i>\n' +
    '        <span class="sr-only" translate>Release</span>\n' +
    '    </button>\n' +
    '\n' +
    '    <button class="Toolbar-button Resize-full" ng-click="openDetailsPopup()"\n' +
    '            title="{{ \'Open in a popup\' | translate }}">\n' +
    '        <i class="glyphicon glyphicon-resize-full"></i>\n' +
    '        <span class="sr-only" translate>Open in a popup</span>\n' +
    '    </button>\n' +
    '</div>\n' +
    '\n' +
    '<tabset class="TaskDetails">\n' +
    '  <tab id="form-tab" heading="{{ \'Form\' | translate }}"\n' +
    '       active="tab.form.active"\n' +
    '       title="{{ \'Task form\' | translate }}"\n' +
    '       select="selectTab(\'form\')">\n' +
    '    <p class="alert alert-info TaskInfo" ng-if="hideForm()" translate>\n' +
    '      This task is completed.\n' +
    '    </p>\n' +
    '\n' +
    '    <div class="TaskForm" ng-if="!hideForm()">\n' +
    '        <div class="FormOverlay-message" ng-if="!isEditable() && !isInactive()">\n' +
    '            <p class="FormOverlay-text" translate>To fill out the form, you need to take this task. This means you will be the only one able to do it. To make it available to the team again, release it.</p>\n' +
    '            <button id="ButtonTakeDetailsOverlay"\n' +
    '                    class="FormOverlay-button btn btn-primary btn-sm"\n' +
    '                    ng-click="onTakeReleaseTask()"\n' +
    '                    title="{{ \'Assign to me. Only I will be able to do it\' | translate }}">\n' +
    '                <i class="icon-assigned">&nbsp;</i>\n' +
    '                <translate>Take</translate>\n' +
    '            </button>\n' +
    '        </div>\n' +
    '      <bonita-iframe-viewer class="FormViewer"\n' +
    '                            tabindex="0"\n' +
    '                            ng-if="!isInactive() && hasForm && !loading"\n' +
    '                            is-editable="isEditable()"\n' +
    '                            frame-url="formUrl">\n' +
    '      </bonita-iframe-viewer>\n' +
    '      <no-form class="FormViewer"\n' +
    '               ng-if="!hasForm && !loading"\n' +
    '               current-task="currentTask"\n' +
    '               editable="isEditable()"\n' +
    '               inactive="isInactive()">\n' +
    '      </no-form>\n' +
    '    </div>\n' +
    '  </tab>\n' +
    '\n' +
    '\n' +
    '  <tab id="comments-tab"\n' +
    '       heading="{{ \'Comments\' | translate }}"\n' +
    '       title="{{ \'Case comments\' | translate }}"\n' +
    '       active="tab.comments.active"\n' +
    '       select="selectTab(\'comments\')">\n' +
    '      <comments ng-if="tab.comments.loaded" case="currentCase"></comments>\n' +
    '  </tab>\n' +
    '\n' +
    '  <tab id="case-tab"\n' +
    '       ng-if="hasOverview"\n' +
    '       heading="{{ \'Overview\' | translate }}"\n' +
    '       title="{{ \'Case overview\' | translate }}"\n' +
    '       active="tab.context.active"\n' +
    '       select="selectTab(\'context\')">\n' +
    '      <bonita-iframe-viewer\n' +
    '        ng-if="tab.context.loaded && !isInactive()"\n' +
    '        class="CaseViewer"\n' +
    '        frame-url="overviewUrl"\n' +
    '        is-editable="true">\n' +
    '      </bonita-iframe-viewer>\n' +
    '  </tab>\n' +
    '</tabset>\n' +
    '');
}]);
})();

(function(module) {
try {
  module = angular.module('org.bonitasoft.portalTemplates');
} catch (e) {
  module = angular.module('org.bonitasoft.portalTemplates', []);
}
module.run(['$templateCache', function($templateCache) {
  $templateCache.put('portalTemplates/user/tasks/list/details/task-no-form.html',
    '      <div class="Viewer-wrapper" ng-if="!inactive">\n' +
    '        <h4>{{currentTask.displayName || currentTask.name}}</h4>\n' +
    '        <p translate>No form is needed. You can enter a comment and confirm.</p>\n' +
    '        <form role="form">\n' +
    '          <div class="form-group">\n' +
    '            <label for="task-comment" translate>Comment:</label>\n' +
    '            <textarea ng-model="currentTask.comment" id="task-comment" class="form-control"></textarea>\n' +
    '          </div>\n' +
    '          <button ng-click="onExecuteTask()" class="btn btn-primary center-block" translate>Submit</button>\n' +
    '        </form>\n' +
    '        <div class="Viewer-overlay" ng-if="!editable"></div>\n' +
    '      </div>\n' +
    '');
}]);
})();

(function(module) {
try {
  module = angular.module('org.bonitasoft.portalTemplates');
} catch (e) {
  module = angular.module('org.bonitasoft.portalTemplates', []);
}
module.run(['$templateCache', function($templateCache) {
  $templateCache.put('portalTemplates/user/tasks/list/filters/task-filters.html',
    '<ul class="TaskFilters nav nav-pills nav-stacked">\n' +
    '  <!-- <a href="#" > is not good for a11n but it\'s a tradeoff for being themable\n' +
    '     that\'s why we use bottstrap markup-->\n' +
    '  <li role="presentation" ng-class="{\'active\':TASK_FILTERS.TODO===taskStatus}">\n' +
    '    <a href="" id="todo-tasks"\n' +
    '       title="{{ \'Show all the tasks I can do: both personal tasks and tasks available to other team members\' | translate }}"\n' +
    '       ng-click="setStatusTaskFilter(TASK_FILTERS.TODO)">\n' +
    '      <span class="badge pull-right" ng-show="count.TODO>0">{{count.TODO}}</span>\n' +
    '      <translate>To do</translate>\n' +
    '    </a>\n' +
    '  </li><!-- tasks to do -->\n' +
    '  <li role="presentation" ng-class="{\'active\':TASK_FILTERS.MY_TASK===taskStatus}">\n' +
    '    <a href="" id="my-tasks"\n' +
    '       title="{{ \'Show my personal tasks: the ones I took and the ones assigned to me, automatically or by a process manager\' | translate }}"\n' +
    '       ng-click="setStatusTaskFilter(TASK_FILTERS.MY_TASK)">\n' +
    '      <span class="badge pull-right" ng-show="count.MY_TASK>0">{{count.MY_TASK}}</span>\n' +
    '      <translate>My tasks</translate>\n' +
    '    </a>\n' +
    '  </li><!-- my tasks -->\n' +
    '  <li role="presentation" ng-class="{\'active\':TASK_FILTERS.DONE===taskStatus}">\n' +
    '    <a href="" id="done-tasks"\n' +
    '       title="{{ \'Show the tasks that I have done\' | translate }}"\n' +
    '       ng-click="setStatusTaskFilter(TASK_FILTERS.DONE)" >\n' +
    '      <translate>Done tasks</translate>\n' +
    '    </a>\n' +
    '  </li> <!-- done tasks -->\n' +
    '</ul>\n' +
    '');
}]);
})();

(function(module) {
try {
  module = angular.module('org.bonitasoft.portalTemplates');
} catch (e) {
  module = angular.module('org.bonitasoft.portalTemplates', []);
}
module.run(['$templateCache', function($templateCache) {
  $templateCache.put('portalTemplates/user/tasks/list/table/task-table.html',
    '<!-- tasks listing -->\n' +
    '<div class="alert alert-noresult" ng-if="tasks.length === 0">\n' +
    '  <span ng-if="isNoTaskFoundVisible()" translate>\n' +
    '    We couldn\'t find what you are looking for.\n' +
    '  </span>\n' +
    '  <span ng-if="isNoTaskAvailableMessageVisible()" translate>\n' +
    '    All done. Good job!\n' +
    '  </span>\n' +
    '  <span ng-if="isNoMyTaskMessageVisible()" translate>\n' +
    '    Your personal task list is empty. You can take a task from the ​<a href="#" ng-click="changeFilter(TASK_FILTERS.TODO)">To do</a> list.\n' +
    '  </span>\n' +
    '  <span ng-if="isNoDoneTaskMessageVisible()" translate>\n' +
    '    No done task yet.\n' +
    '  </span>\n' +
    '</div>\n' +
    '<div bonitable\n' +
    '  on-sort="sort(options)"\n' +
    '  sort-options="sortOption"\n' +
    '  bo-repeatable\n' +
    '  repeatable-config="columnSettings">\n' +
    '  <div class="GroupAction clearfix" ng-show="tasks.length > 0">\n' +
    '    <div class="GroupAction-button pull-left" ng-show="canDoGroupAction()">\n' +
    '      <button id="btn-group-assigntome" class="btn btn-primary" type="button" title="{{ \'Assign to me. Only I will be able to do it\' | translate }}"\n' +
    '         ng-disabled="!canTake($selectedItems)" ng-if="request.taskFilter !== TASK_FILTERS.MY_TASK" ng-click="takeTasks($selectedItems)"><i class="icon-assigned">&nbsp;</i><translate>Take</translate>\n' +
    '      </button>\n' +
    '      <button id="btn-group-unassign" class="btn btn-default"  type="button" title="{{ \'Unassign. This will make it available to team again\' | translate }}"\n' +
    '        ng-disabled="!canRelease($selectedItems)" ng-if="request.taskFilter !== TASK_FILTERS.POOL_TASK" ng-click="releaseTasks($selectedItems)"><i class="icon-unassigned">&nbsp;</i><translate>Release</translate>\n' +
    '      </button>\n' +
    '    </div>\n' +
    '    <div class="PaginationInfo pull-right">\n' +
    '      <!-- pagination -->\n' +
    '      <span class="PaginationInfo-summary">\n' +
    '        {{getPaginationStatus()}}\n' +
    '      </span>\n' +
    '      <pagination\n' +
    '        class="PaginationInfo-pagination"\n' +
    '        ng-show="request.pagination.total >= request.pagination.numberPerPage"\n' +
    '        total-items="request.pagination.total"\n' +
    '        ng-model="request.pagination.currentPage"\n' +
    '        items-per-page="request.pagination.numberPerPage"\n' +
    '        max-size="5"\n' +
    '        boundary-links="false"\n' +
    '        ng-change="refresh()"\n' +
    '        previous-text="&lsaquo;" next-text="&rsaquo;"\n' +
    '        rotate="false">\n' +
    '      </pagination>\n' +
    '      <table-settings\n' +
    '        columns="$columns"\n' +
    '        page-size="request.pagination.numberPerPage" sizes="pageSizes"\n' +
    '        update-page-size="pageSizeHandler(size)"\n' +
    '        update-visibility="visibilityHandler(field, $columns)"\n' +
    '        ></table-settings>\n' +
    '      </table-settings>\n' +
    '    </div>\n' +
    '  </div>\n' +
    '  <div class="table-responsive TaskTable" ng-hide="tasks.length === 0">\n' +
    '    <table class="table table-hover table-striped TaskTable" ng-class="{\'TaskTable-filterDone\': TASK_FILTERS.DONE === request.taskFilter}">\n' +
    '      <thead>\n' +
    '        <tr>\n' +
    '          <th data-ignore class="Cell--checkbox" ng-if="canDoGroupAction()">\n' +
    '            <div bo-selectall></div>\n' +
    '          </th>\n' +
    '          <th data-ignore class="Cell--assignee">\n' +
    '            <i class="icon-assigned" title="{{ \'Available or My tasks\' | translate }}"></i>\n' +
    '          </th><!-- assigned icon -->\n' +
    '          <th class="text-right">{{ \'Task Id\' | translate }}</th>\n' +
    '          <th bo-sorter="displayName">{{ \'Task name\' | translate }}</th>\n' +
    '          <th>{{ \'Description\' | translate }}</th>\n' +
    '          <th bo-sorter="rootCaseId" class="text-right">{{ \'Case\' | translate }}</th>\n' +
    '          <th>{{ \'Process name\' | translate }}</th>\n' +
    '          <th bo-sorter="reachedStateDate" visible="false" class="text-right">{{ \'Last update\' | translate }}</th>\n' +
    '          <th class="text-right">{{ \'Assigned on\' | translate }}</th>\n' +
    '          <th bo-sorter="dueDate" class="text-right TaskTable-dueDateHeader">{{ \'Due date\' | translate }}</th>\n' +
    '          <th bo-sorter="priority">{{ \'Priority\' | translate }}</th>\n' +
    '          <th data-ignore class="RowActions" ng-if="mode!==\'mid\'"></th>\n' +
    '        </tr>\n' +
    '      </thead>\n' +
    '      <tbody>\n' +
    '        <tr class="Line"\n' +
    '            ng-repeat="task in tasks"\n' +
    '            ng-click="onClickTask(task)"\n' +
    '            ng-mouseover="showTaskButtons(task)"\n' +
    '            ng-mouseleave="hideTaskButtons(task)"\n' +
    '            ng-class="{\'info\':task === currentTask, \'TaskTable-line--overdue\': isOverdue(task)}"\n' +
    '            tabindex="0">\n' +
    '\n' +
    '          <td class="Cell--checkbox" ng-if="canDoGroupAction()">\n' +
    '            <input type="checkbox" bo-selector="task" ng-click="onCheckBoxChange($event, $index)">\n' +
    '          </td>\n' +
    '\n' +
    '          <td class="TaskTable-icon">\n' +
    '            <i class="icon-assigned" title="{{ \'Only I can do this task\' | translate }}" ng-if="user.user_id===task.assigned_id"></i>\n' +
    '          </td>\n' +
    '\n' +
    '          <td class="text-right TaskTable-id">{{::task.id}}</td>\n' +
    '          <td class="TaskTable-displayName" title="{{::task.displayName}}">{{::task.displayName}}</td>\n' +
    '          <td class="TaskTable-displayDescription" title="{{::task.displayDescription}}">{{::task.displayDescription}}</td>\n' +
    '          <td class="text-right Cell--sortable TaskTable-caseId">{{::task.caseId}}</td>\n' +
    '          <td class="TaskTable-processName">{{::task.rootContainerId.displayName}}</td>\n' +
    '          <td class="text-right TaskTable-lastUpdateDate" title="{{::task.last_update_date|moment:\'LLL\'}}">{{::task.last_update_date|moment:\'MMM DD LT\'}}</td>\n' +
    '          <td class="text-right TaskTable-assignedDate" title="{{::task.assigned_date|moment:\'LLL\'}}">{{::task.assigned_date|moment:\'MMM DD LT\'}}</td>\n' +
    '          <td class="text-right Cell--sortable TaskTable-dueDate" title="{{::getDueDateTitle(task)}}">{{::task.dueDate|moment:\'MMM DD LT\'}}</td>\n' +
    '          <td class="TaskTable-priority">{{::getPriority(task.priority)}}</td>\n' +
    '          <td class="Cell--with-actions TaskTable-actions" ng-switch on="mode" ng-if="mode!==\'mid\'">\n' +
    '            <button class="btn btn-default" type="button"\n' +
    '                    ng-switch-when="max"\n' +
    '                    ng-if="request.taskFilter !== TASK_FILTERS.DONE"\n' +
    '                    ng-show="task.btnVisible"\n' +
    '                    title="{{ \'Open the task to perform it\' | translate }}">\n' +
    '              <i class="glyphicon glyphicon-edit"></i>\n' +
    '              <span class="sr-only" translate>Open the task to perform it</span>\n' +
    '            </button>\n' +
    '            <a class="btn btn-xs btn-default" type="button"\n' +
    '               ng-switch-when="min"\n' +
    '               ng-click="goToDetail(\'details\')"\n' +
    '               title="{{ \'View this task\' | translate }}" translate>\n' +
    '              View task\n' +
    '            </a>\n' +
    '          </td>\n' +
    '        </tr>\n' +
    '      </tbody>\n' +
    '    </table>\n' +
    '  </div>\n' +
    '  <div class="GroupAction clearfix" ng-show="tasks.length > 0">\n' +
    '    <div class="PaginationInfo pull-right" >\n' +
    '      <!-- pagination -->\n' +
    '      <span class="PaginationInfo-summary">\n' +
    '        {{getPaginationStatus()}}\n' +
    '      </span>\n' +
    '      <pagination\n' +
    '        class="PaginationInfo-pagination"\n' +
    '        ng-show="request.pagination.total >= request.pagination.numberPerPage"\n' +
    '        total-items="request.pagination.total"\n' +
    '        ng-model="request.pagination.currentPage"\n' +
    '        items-per-page="request.pagination.numberPerPage"\n' +
    '        max-size="5"\n' +
    '        boundary-links="false"\n' +
    '        ng-change="refresh()"\n' +
    '        previous-text="&lsaquo;" next-text="&rsaquo;"\n' +
    '        rotate="false">\n' +
    '      </pagination>\n' +
    '    </div>\n' +
    '  </div>\n' +
    '</div>\n' +
    '\n' +
    '');
}]);
})();

(function(module) {
try {
  module = angular.module('org.bonitasoft.portalTemplates');
} catch (e) {
  module = angular.module('org.bonitasoft.portalTemplates', []);
}
module.run(['$templateCache', function($templateCache) {
  $templateCache.put('portalTemplates/user/tasks/list/common/directive/bonita-iframe-viewer.html',
    '<div class="Viewer-wrapper">\n' +
    '  <iframe\n' +
    '    id="bonitaframe"\n' +
    '    class="Viewer-frame"\n' +
    '    seamless\n' +
    '    width="100%" height="100%"\n' +
    '    frameborder="0"></iframe>\n' +
    '  <div class="Viewer-overlay" ng-if="!isEditable"></div>\n' +
    '</div>\n' +
    '');
}]);
})();
