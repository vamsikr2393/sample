This is a look & feel archive for Bonita Mobile.
You can customize this look & feel by modifying the existing resources or by adding or removing some.

Content detail:
css											Directory containing CSS files.
css/jquery.mobile.structure-1.2.0.min.css	JQuery Mobile default CSS
css/style.css								JQuery Mobile default theme CSS
img											Directory of images. These images are the size needed for the standard layout. If you change the layout, you might need to adjust the images sizes. If you want to use an image that is a different size, you might need to modify the layout.
themes										Directory containing CSS files overriding the JQuery files (theme for Bonita mobile).
themes/images								Directory of images used in the themes.
themes/bonitasoft.css						Theme CSS.
themes/bonitasoft.min.css					Minified theme CSS.